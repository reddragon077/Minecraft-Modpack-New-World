NEW WORLD — SHIP DIMENSION PROTOTİPİ
====================================

Kurulum:
1) Bu ZIP dosyasını açmadan modpack içindeki:
   kubejs/data/
   klasörüne kopyalayın.

2) Oyunu tamamen kapatıp yeniden açın.

3) Test dünyasında şu komutu çalıştırın:
   /execute in new_world:ship run tp @s 0 80 0

Beklenen sonuç:
- Tamamen boş bir dimension
- Sabit gece/yıldız görünümü
- Arazi, yapı, göl veya doğal üretim yok
- Geminin merkezi için önerilen koordinat: 0 80 0

Önemli:
- Bu paket yalnız Ship Dimension'ı oluşturur.
- Oyuncunun yeni dünyada doğrudan bu dimension'da başlaması için
  ayrıca başlangıç dimension ayarı/modu yapılandırılacaktır.
- Gemiyi tasarlarken geçici platformu komutla oluşturabilirsiniz:
  /execute in new_world:ship run fill -8 79 -8 8 79 8 minecraft:smooth_stone

Dimension kimliği:
new_world:ship